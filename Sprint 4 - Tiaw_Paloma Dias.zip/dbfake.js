var db = {
    dados: [
        {
            nome: 'Adotar é o Bicho',
            cidade: 'Belo Horizonte',
            imagem: 'https://picsum.photos/id/1025/200',
            telefone: '(31) 3764-9980',
        }, {
            nome: '4 Patas',
            cidade: 'Belo Horizonte',
            imagem: 'https://picsum.photos/id/237/200',
            telefone: '(31) 97564-4355',
        }, {
            nome: 'Guardiões dos Animais',
            cidade: 'Contagem',
            imagem: 'https://picsum.photos/id/169/200',
            telefone: '(31) 3647-2210',
        }, {
            nome: 'Selva Encantada',
            cidade: 'Nova Lima',
            imagem: 'https://picsum.photos/id/10/200',
            telefone: '(31) 3647-2223',
        }, {
            nome: 'Aumigos',
            cidade: 'Caeté',
            imagem: 'https://picsum.photos/id/1062/200',
            telefone: '(31) 3647-2340',
        }, {
            nome: 'Animals',
            cidade: 'Serra do Cipó',
            imagem: 'https://picsum.photos/id/200/200',
            telefone: '(31) 3647-2234',
        }, {
            nome: 'Exoticos',
            cidade: 'Santa Bárbara',
            imagem: 'https://picsum.photos/id/219/200',
            telefone: '(31) 3647-3450',
        }, {
            nome: 'Balaio de Gato',
            cidade: 'Contagem',
            imagem: 'https://picsum.photos/id/40/200',
            telefone: '(31) 3647-2219',
        }, {
            nome: 'Patinhas fofas',
            cidade: 'Belo Horizonte',
            imagem: 'https://picsum.photos/id/433/200',
            telefone: '(31) 3647-3310',
        }, {
            nome: 'ONG Resgate',
            cidade: 'Contagem',
            imagem: 'https://picsum.photos/id/582/200',
            telefone: '(31) 3647-2880',
        }, {
            nome: 'Paraíso Animal',
            cidade: 'Betim',
            imagem: 'https://picsum.photos/id/584/200',
            telefone: '(31) 3655-2210',
        }, {
            nome: 'Cãoninos',
            cidade: 'Contagem',
            imagem: 'https://picsum.photos/id/659/200',
            telefone: '(31) 3647-2290',
        }, {
            nome: 'Resgate em ação',
            cidade: 'Betim',
            imagem: 'https://picsum.photos/id/718/200',
            telefone: '(31) 3657-2260',
        }, {
            nome: 'Operação Selva',
            cidade: 'Baldim',
            imagem: 'https://picsum.photos/id/790/200',
            telefone: '(31) 3647-2910',
        }, {
            nome: 'Fofura animal',
            cidade: 'Belo Horizonte',
            imagem: 'https://picsum.photos/id/837/200',
            telefone: '(31) 3647-2999',
        }, {
            nome: 'Ação Floresta',
            cidade: 'Igarapé',
            imagem: 'https://picsum.photos/id/1003/200',
            telefone: '(31) 3647-4444',
        }
    ]
}